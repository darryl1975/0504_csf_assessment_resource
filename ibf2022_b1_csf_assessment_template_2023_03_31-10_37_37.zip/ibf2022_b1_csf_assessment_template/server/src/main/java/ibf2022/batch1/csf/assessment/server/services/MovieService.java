package ibf2022.batch1.csf.assessment.server.services;

import java.util.List;

import ibf2022.batch1.csf.assessment.server.models.Review;;

public class MovieService {

	// TODO: Task 4
	// DO NOT CHANGE THE METHOD'S SIGNATURE
	public List<Review> searchReviews(String query) {
		return null;
	}

}
